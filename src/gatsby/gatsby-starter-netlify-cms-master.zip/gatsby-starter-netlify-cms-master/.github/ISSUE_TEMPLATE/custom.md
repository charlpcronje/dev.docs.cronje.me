---
name: Custom issue template
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

---
name: Other
about: Something else

---

<!-- Bug reports and Feature requests must use other templates, or will be closed -->
<!-- Please ask questions on the NetlifyCMS Gitter channel (https://gitter.im/netlify/NetlifyCMS). -->
<!-- Issues which contain questions or support requests will be closed. -->
