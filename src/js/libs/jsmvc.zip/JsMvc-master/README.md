JsMvc
=====

A small JavaScript framework to implement mvc style navigation in a single page web application.

Related CodeProject article: 
http://www.codeproject.com/Articles/869488/JavaScript-MVC-Style-Framework-in-Less-Than-Lines
